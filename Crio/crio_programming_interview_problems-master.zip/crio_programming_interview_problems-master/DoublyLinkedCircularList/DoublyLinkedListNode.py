# CRIO_SOLUTION_START_MODULE_L1_PROBLEMS
# CRIO_SOLUTION_END_MODULE_L1_PROBLEMS

class DoublyLinkedListNode:
    def __init__(self, x, p= None,n= None):
        self.val = x
        self.prev = p
        self.next = n