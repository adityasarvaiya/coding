def trailingZeroes(n):
    # TODO: CRIO_TASK_MODULE_L1_PROBLEMS
    # Your implementation goes here

    return 0

if __name__ == '__main__':
    n = int(input())
    result = trailingZeroes(n)
    print(result)
