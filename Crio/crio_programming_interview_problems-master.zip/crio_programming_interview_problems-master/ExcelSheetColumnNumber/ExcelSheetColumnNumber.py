def titleToNumber(s):
    # TODO: CRIO_TASK_MODULE_L1_PROBLEMS
    # Your implementation goes here

    return 0

if __name__ == '__main__':
    s = input()
    result = titleToNumber(s)
    print(result)
