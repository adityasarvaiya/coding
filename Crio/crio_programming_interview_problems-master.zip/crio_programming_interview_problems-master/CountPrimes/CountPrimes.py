def countPrimes(n):
	ans = 0
	# CRIO_SOLUTION_START_MODULE_L1_PROBLEMS

	# CRIO_SOLUTION_END_MODULE_L1_PROBLEMS
	return ans

if __name__ == '__main__':
	n = int(input())
	result = countPrimes(n)
	print(result)
