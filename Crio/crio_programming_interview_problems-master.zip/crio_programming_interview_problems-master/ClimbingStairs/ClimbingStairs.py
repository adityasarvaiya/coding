def climbStairs(numberOfStairs):
    # TODO: CRIO_TASK_MODULE_L1_PROBLEMS
    # Your implementation goes here

    return 0

if __name__ == '__main__':
    numberOfStairs = int(input())
    result = climbStairs(numberOfStairs)
    print(result)
