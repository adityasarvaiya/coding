def divide(dividend, divisor):
    # TODO: CRIO_TASK_MODULE_L2_PROBLEMS
    # Your implementation goes here

    return 0

if __name__ == '__main__':
    dividend = int(input())
    divisor = int(input())
    result = divide(dividend, divisor)
    print(result)
    