class solution {
    public int add(int a, int b) {
        // CRIO_SOLUTION_START_MODULE_L1_PROBLEMS
        return a + b;
        // CRIO_SOLUTION_END_MODULE_L1_PROBLEMS
    }
}

