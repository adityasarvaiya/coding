
class Addition {
public:
    int add(int a, int b) {
        int res = 0;
        // CRIO_SOLUTION_START_MODULE_L1_PROBLEMS
        res = a + b;
        // CRIO_SOLUTION_END_MODULE_L1_PROBLEMS
        return res;
    }
};


