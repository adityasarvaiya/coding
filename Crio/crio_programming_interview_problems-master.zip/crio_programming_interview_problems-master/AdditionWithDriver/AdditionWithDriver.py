from solution import add

if __name__ == '__main__':

    inp = input().split()

    a = int(inp[0])

    b = int(inp[1])

    print(add(a,b))
