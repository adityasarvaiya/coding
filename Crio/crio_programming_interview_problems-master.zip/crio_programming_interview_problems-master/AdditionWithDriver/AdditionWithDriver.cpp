#include <bits/stdc++.h>
#include "solution.cpp"

using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    int result = Addition().add(a, b);
    cout << result;
}
