import java.util.*;

public class Solution {
    Node threeDimensionalMatrixToLinkedList(int cuboid[][][], int dimx, int dimy, int dimz) {
    }
}
