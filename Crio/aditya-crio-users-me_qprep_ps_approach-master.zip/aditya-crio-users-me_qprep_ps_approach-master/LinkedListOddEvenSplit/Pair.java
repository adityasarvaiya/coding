import crio.ds.List.ListNode;

public class Pair {
    public int x;
    public ListNode y;
    Pair(int x, ListNode y) {
        this.x = x;
        this.y = y;
    }
    public int getX() {
        return x;
    }
    public ListNode getY() {
        return y;
    }
}
